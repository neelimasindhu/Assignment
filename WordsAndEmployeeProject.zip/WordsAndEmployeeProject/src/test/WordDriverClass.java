package test;

public class WordDriverClass {

	public static void main(String[] args) {
		
		
		Words words= new Words();
		
		String sentence="I am here here";
		
		System.out.println(words.getNumberOfWords(sentence));
	}

}
