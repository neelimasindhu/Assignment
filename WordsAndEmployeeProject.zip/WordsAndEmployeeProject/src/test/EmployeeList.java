package test;

import java.util.ArrayList;
import java.util.List;

public class EmployeeList {
	
	
	List<Employee> employeeList= new ArrayList<Employee>();
	
	public List<Employee> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}

	public Employee getEmployeeByID(int id){
		
		Employee employee=null;
		
		for(Employee emp:this.employeeList){
			
			
			if(emp.getEmployeeId()==id){
				
				employee=emp;
			}
		
		}
		
		return employee;
		
		
	}

}
