package test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Words {
	
	public Map<String,Integer> getNumberOfWords(String sentence){
		
	
		ArrayList<String> unique= new ArrayList<String>();
		String[] total=sentence.split(" ");
		Map<String,Integer> number= new HashMap<String,Integer>();
		String first=(total[0]).toLowerCase();
		unique.add(first);
		for (int i = 0;i < total.length; i++){
		    
			if(!(unique.contains(total[i].toLowerCase()))){
				
				unique.add(total[i].toLowerCase());
			}
			
		}
		
		
		
		for(int i = 0;i < unique.size(); i++){
			
			int count=0;
			for(int j=0;j<total.length; j++){
				
				if((unique.get(i).equals(total[j].toLowerCase()))){
					
					count++;
				}
				
			}
			
			number.put(unique.get(i), count);
			
		}
		
		
		return number;
		
		
	}

}
