package test;

import java.util.ArrayList;

public class EmployeeDriverClass {

	public static void main(String[] args) {
		
		EmployeeList empList= new EmployeeList();
		ArrayList<Employee> empArrayList=new ArrayList<Employee>();
		Employee firstEmployee= new Employee(1,"Geetha","Telli");
		Employee secondEmployee= new Employee(2,"seetha","Velli");
		Employee thirdEmployee= new Employee(2,"Varna","Veda");
		empArrayList.add(firstEmployee);
		empArrayList.add(secondEmployee);
		empArrayList.add(thirdEmployee);
		empList.setEmployeeList(empArrayList);

		Employee empObject= empList.getEmployeeByID(1);
		
		System.out.println("Employee id , first name, last name is :"+empObject.getEmployeeId()+" "+empObject.getFirstName()+" "+empObject.getLastName());
		

	}

}
